self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fb3b59337348eb6e71be510a495358a0",
    "url": "/index.html"
  },
  {
    "revision": "159c8f1c26f63e2cf3c3",
    "url": "/static/css/main.d6e4675a.chunk.css"
  },
  {
    "revision": "daccb59ed3c8cec51699",
    "url": "/static/js/2.a7433186.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/static/js/2.a7433186.chunk.js.LICENSE"
  },
  {
    "revision": "159c8f1c26f63e2cf3c3",
    "url": "/static/js/main.ba33ec00.chunk.js"
  },
  {
    "revision": "7ebe5cdd7d278cf54f61",
    "url": "/static/js/runtime-main.44184d1d.js"
  },
  {
    "revision": "6e5393a64ca23c455e8568d409e82da6",
    "url": "/static/media/Pokemon Hollow.6e5393a6.ttf"
  },
  {
    "revision": "36d26dbcd032a9d91d891c9f22dfdec6",
    "url": "/static/media/Pokemon Solid.36d26dbc.ttf"
  }
]);